create procedure delete_stu(IN p_id int)
  BEGIN
delete from stu where id = p_id;
END;

