create procedure check_stu(IN stu_id int)
  begin select stu_id; set stu_id=2; SELECT stu_id; end;

